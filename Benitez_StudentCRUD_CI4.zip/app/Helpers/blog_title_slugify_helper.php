<?php

use App\Models\BlogModel;

if (! function_exists('blog_title_slugify'))
{
    function blog_title_slugify(string $title): string
    {
        helper('url');
        
        // Basic slugify (use url_title or better custom logic)
        $slug = url_title(iconv('UTF-8', 'ASCII//TRANSLIT', $title), '-', true);
        
        $newSlug = $slug;
        $i = 1;

        // Load the BlogModel
        $blogModel = new BlogModel();

        // Check if slug already exists
        while ($blogModel->where('slug', $newSlug)->first()) {
            $newSlug = $slug . '-' . $i;
            $i++;
        }

        return $newSlug;
    }
}

