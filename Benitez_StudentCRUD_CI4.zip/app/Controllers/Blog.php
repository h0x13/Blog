<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BlogModel;
use App\Models\CategoryModel;
use App\Models\BlogCategoryModel;

class Blog extends BaseController
{
    protected $blogModel;
    protected $categoryModel;
    protected $blogCategoryModel;
    protected $validation;

    public function __construct()
    {
        $this->blogModel = model(BlogModel::class);
        $this->categoryModel = model(CategoryModel::class);
        $this->blogCategoryModel = model(BlogCategoryModel::class);
        $this->validation = \Config\Services::validation();
    }

    public function index()
    {
        $data = [
            'blogs' => $this->blogModel
                ->select('blogs.*, users.first_name, users.last_name, users.middle_name')
                ->join('users', 'users.user_id = blogs.user_id')
                ->findAll(),
            'validation' => $this->validation
        ];
        return view('blogs', $data);
    }

    public function create() {
        $data['categories'] = $this->categoryModel->findAll();
        return view('blog_pages/add.php', $data);
    }

    public function store() {
        helper('blog_title_slugify');

        $rules = [
            'title' => 'required|min_length[5]|max_length[255]',
            'content' => 'required',
            'visibility' => 'required|in_list[private,public]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getErrors());
        }

        $user_id = 2;// session()->get('user_id');
        
        $data = [
            'user_id' => $user_id,
            'title' => $this->request->getPost('title'),
            'content' => $this->request->getPost('content'),
            'visibility' => $this->request->getPost('visibility'),
            'slug' => blog_title_slugify($this->request->getPost('title'))
        ];

        $this->blogModel->db->transBegin();
        try {
            $blog_id = $this->blogModel->insert($data);
            
            // Save categories if selected
            $categories = $this->request->getPost('categories');
            if (!empty($categories)) {
                foreach ($categories as $category_id) {
                    $this->blogCategoryModel->insert([
                        'blog_id' => $blog_id,
                        'category_id' => $category_id
                    ]);
                }
            }
            
            $this->blogModel->db->transCommit();
            return redirect()->to('blogs')->with('success', 'Blog created successfully!');
            
        } catch (\Exception $e) {
            $this->blogModel->db->transRollback();
            return redirect()->back()->withInput()->with('error', 'An error occurred while creating the blog.');
        }
    }
}
