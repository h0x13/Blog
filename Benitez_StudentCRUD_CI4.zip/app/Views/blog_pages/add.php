<?= $this->extend('templates/base') ?>

<?= $this->section('title') ?>Create New Blog<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<script src="<?= base_url('assets/js/jquery-3.6.0.min.js') ?>"></script>
<link rel="stylesheet" href="<?= base_url('plugins/summernote/summernote-bs5.css') ?>">
<script src="<?= base_url('plugins/summernote/summernote-bs5.js') ?>"></script>
<style>
    .form-section {
        margin-bottom: 2rem;
        border-bottom: 1px solid #eee;
        padding-bottom: 1.5rem;
    }
    .form-section:last-child {
        border-bottom: none;
    }
    .section-header {
        font-size: 1.2rem;
        margin-bottom: 1rem;
        font-weight: 500;
        color: #444;
    }
    .action-buttons {
        padding-top: 1rem;
    }
    .visibility-options {
        padding: 1rem;
        background-color: #f8f9fa;
        border-radius: 5px;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<main class="app-main">
    <div class="app-content-header">
        <div class="container-fluid">
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="d-flex justify-content-between align-items-center">
                        <h2 class="m-0">Create New Blog</h2>
                        <a href="<?= base_url('blogs') ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Blogs
                        </a>
                    </div>
                </div>
            </div>
            
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?= session('error') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?= session('success') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <form action="<?= base_url('blogs/add') ?>" method="post">
                        <?= csrf_field() ?>
                        
                        <div class="form-section">
                            <div class="section-header">
                                <i class="bi bi-pencil-square"></i> Basic Information
                            </div>
                            <div class="mb-3">
                                <label for="title" class="form-label">Blog Title</label>
                                <input type="text" class="form-control form-control-lg" id="title" name="title" value="<?= old('title') ?>" placeholder="Enter a descriptive title" required>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <div class="section-header">
                                <i class="bi bi-file-richtext"></i> Content
                            </div>
                            <div class="mb-3">
                                <textarea id="blogContent" name="content"><?= old('content') ?></textarea>
                            </div>
                        </div>

                        <div class="form-section">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="section-header">
                                        <i class="bi bi-eye"></i> Visibility
                                    </div>
                                    <div class="visibility-options">
                                        <div class="form-check form-check-inline mb-2">
                                            <input class="form-check-input" type="radio" name="visibility" id="privateRadioBtn" value="private" checked>
                                            <label class="form-check-label" for="privateRadioBtn">
                                                <i class="bi bi-lock-fill text-danger"></i> Private
                                                <small class="text-muted d-block">Only you can see this blog</small>
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="visibility" id="publicRadioBtn" value="public">
                                            <label class="form-check-label" for="publicRadioBtn">
                                                <i class="bi bi-globe text-success"></i> Public
                                                <small class="text-muted d-block">Anyone can view this blog</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="section-header d-flex justify-content-between align-items-center">
                                        <div><i class="bi bi-tags"></i> Categories</div>
                                        <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#categoryModal">
                                            <i class="bi bi-plus"></i> Add Category
                                        </button>
                                    </div>
                                    <div id="categoryList" class="mt-2">
                                        <div class="text-muted small fst-italic">No categories selected</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="action-buttons d-flex justify-content-end border-top pt-3">
                            <button type="button" id="previewBtn" class="btn btn-outline-primary me-2">
                                <i class="bi bi-eye"></i> Preview
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg"></i> Create Blog
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="categoryModalLabel">
                    <i class="bi bi-tag"></i> Add Category
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="addCategorySelect" class="form-label">Select Category</label>
                    <select id="addCategorySelect" class="form-select">
                        <?php foreach($categories as $category): ?>
                            <option value="<?= $category['category_id'] ?>"><?= $category['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="addCategoryBtn" class="btn btn-success" data-bs-dismiss="modal">
                    <i class="bi bi-plus"></i> Add
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="previewModalLabel">Blog Preview</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h1 id="previewTitle" class="mb-4"></h1>
                <div id="previewContent" class="border-bottom pb-4 mb-4"></div>
                <div class="d-flex">
                    <div id="previewVisibility" class="me-3"></div>
                    <div id="previewCategories"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>

<?php
    // Create a map: [category_id => name]
    $categoryMap = array_column($categories, 'name', 'category_id');

    // Prepare the old selected categories in a simple loop
    $oldSelectedCategories = [];

    if (old('categories')) {
        foreach (old('categories') as $catId) {
            if (isset($categoryMap[$catId])) {
                $oldSelectedCategories[] = [
                    'id' => $catId,
                    'content' => $categoryMap[$catId]
                ];
            }
        }
    }
?>

<script>
    $(document).ready(function() {
        // Initialize Summernote with more options
        $('#blogContent').summernote({
            placeholder: 'Start writing your blog post here...',
            height: 300,
            callbacks: {
                onImageUpload: function(files) {
                    // You can implement image upload functionality here
                    console.log('Image upload triggered');
                }
            }
        });

        // Categories management
        const categories = <?= json_encode($oldSelectedCategories) ?>;
        const categoryListContainer = document.getElementById('categoryList');
        const addCategoryBtn = document.getElementById('addCategoryBtn');
        const addCategorySelect = document.getElementById('addCategorySelect');

        function createCategoryBadge(id, content) {
            const categoryBadge = document.createElement('span');
            categoryBadge.className = 'badge rounded-pill border border-secondary text-secondary d-inline-flex align-items-center ms-2';
            categoryBadge.innerHTML = `
                <span>${content}</span>
                <input type="hidden" name="categories[]" value="${id}">
                <button type="button" class="btn btn-link btn-sm category-badge-remove p-0 m-0 text-dark" data-remove-id="${id}">
                    <i class="bi bi-x"></i>
                </button>
            `;
            return categoryBadge;
        }

        function removeBadgeById(id) {
            categories.forEach((category, index) => {
                if (parseInt(category.id) === parseInt(id)) {
                    categories.splice(index, 1);
                }
            });
        }

        function renderCategoryBadges() {
            categoryListContainer.innerHTML = '';
            if (categories.length === 0) {
                categoryListContainer.innerHTML = '<div class="text-muted small fst-italic">No categories selected</div>';
                return;
            }
            
            categories.forEach(category => {
                categoryListContainer.appendChild(createCategoryBadge(category.id, category.content));
            });
        }

        addCategoryBtn.addEventListener('click', () => {
            if (categories.some(category => parseInt(category.id) === parseInt(addCategorySelect.value))) {
                return;
            }
            const content = addCategorySelect.options[addCategorySelect.selectedIndex].text;
            categories.push({id: addCategorySelect.value, content: content});
            renderCategoryBadges();
        });
        
        categoryListContainer.addEventListener('click', event => {
            const removedBadge = event.target.closest('.category-badge-remove');
            if (removedBadge) {
                const removeId = removedBadge.getAttribute('data-remove-id');
                removeBadgeById(removeId);
                renderCategoryBadges();
            }
        });

        // Preview functionality
        document.getElementById('previewBtn').addEventListener('click', () => {
            const title = document.getElementById('title').value || 'Untitled Blog';
            const content = $('#blogContent').summernote('code');
            const visibility = document.querySelector('input[name="visibility"]:checked').value;
            
            document.getElementById('previewTitle').textContent = title;
            document.getElementById('previewContent').innerHTML = content;
            
            // Set visibility badge
            const visibilityElement = document.getElementById('previewVisibility');
            if (visibility === 'private') {
                visibilityElement.innerHTML = '<span class="badge bg-danger"><i class="bi bi-lock-fill"></i> Private</span>';
            } else {
                visibilityElement.innerHTML = '<span class="badge bg-success"><i class="bi bi-globe"></i> Public</span>';
            }
            
            // Set categories
            const categoriesElement = document.getElementById('previewCategories');
            categoriesElement.innerHTML = '';
            if (categories.length > 0) {
                categories.forEach(category => {
                    const badge = document.createElement('span');
                    badge.className = 'badge bg-secondary me-1';
                    badge.textContent = category.content;
                    categoriesElement.appendChild(badge);
                });
            } else {
                categoriesElement.innerHTML = '<span class="text-muted">No categories</span>';
            }
            
            // Show modal
            const previewModal = new bootstrap.Modal(document.getElementById('previewModal'));
            previewModal.show();
        });
        
        if (categories) {
            renderCategoryBadges();
        }
    });
</script>
<?= $this->endSection() ?>
